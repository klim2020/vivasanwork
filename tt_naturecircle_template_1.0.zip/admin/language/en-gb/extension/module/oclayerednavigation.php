<?php
// Heading
$_['heading_title']       = '<b><i>OC Layered Navigation Ajax</i></b>';
$_['page_title']       = 'OC Layered Navigation Ajax';

// Text
$_['text_extension']   = 'Extensions';
$_['text_edit']           = 'Edit Layered Navigation Module';
$_['text_success']        = 'Success: You have modified module Layered Navigation!';

// Entry
$_['entry_status']          = 'Enable Layered Navigation';
$_['entry_image']           = 'Ajax Loader Image';

//Error
$_['error_code']           = 'Modification requires a unique ID code!';
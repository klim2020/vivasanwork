<?php
// Text
$_['button_read_more']         		 = 'Read more';
$_['text_blog_empty']           			 = 'No articles';
$_['text_post_by']           			 = 'post by: ';
$_['text_headingtitle']           			 = 'from our blog';
$_['text_blog'] = 'Blog';
$_['sub_title'] = 'Latest new';


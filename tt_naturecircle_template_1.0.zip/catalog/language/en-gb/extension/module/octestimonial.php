<?php
// Heading 
$_['heading_title']  = 'What our clients say';
$_['text_readmore']  = 'Read more';
$_['text_empty']  = 'There is no testimonial';
$_['sub_title']  = 'Testimonials';
?>
<?php
// Heading
$_['heading_title'] = 'Layered Navigation';
$_['text_byprice'] = 'Price Filter';
